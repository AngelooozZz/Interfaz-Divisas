import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import javax.swing.JLabel;



public class EtiquetaResultados extends JLabel{
    
    public EtiquetaResultados(){
        this.setBackground(Color.white);
        this.setForeground(Color.black);
        this.setPreferredSize(new Dimension(222 , 26));
    }
    
}
